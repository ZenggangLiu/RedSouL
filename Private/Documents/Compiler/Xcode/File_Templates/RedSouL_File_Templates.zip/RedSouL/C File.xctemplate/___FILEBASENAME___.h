/*******************************************************************************
                                                                                
         ____            ____        ____                     __                
        /\  _`\         /\  _`\     /\  _`\                  /\ \               
        \ \ \L\ \     __\ \ \/\ \   \ \,\L\_\    ___   __  __\ \ \              
         \ \ ,  /   /'__`\ \ \ \ \   \/_\__ \   / __`\/\ \/\ \\ \ \  __         
          \ \ \\ \ /\  __/\ \ \_\ \    /\ \L\ \/\ \L\ \ \ \_\ \\ \ \L\ \        
           \ \_\ \_\ \____\\ \____/    \ `\____\ \____/\ \____/ \ \____/        
            \/_/\/ /\/____/ \/___/      \/_____/\/___/  \/___/   \/___/         
--------------------------------------------------------------------------------

    Author:   Zenggang Liu
    Created:  ___DATE___  @  ___TIME___
    FileName: ___FILENAME___ @ ReD SouL Project
    Usage:  
    History:
             - created: ___DATE___: Zenggang Liu
    
*******************************************************************************/

#ifndef ___UUIDASIDENTIFIER____CREATED_AT____YEAR____YEAR_HEADER__
#define ___UUIDASIDENTIFIER____CREATED_AT____YEAR____YEAR_HEADER__


#pragma once




#endif //___UUIDASIDENTIFIER____CREATED_AT____YEAR____YEAR_HEADER__
