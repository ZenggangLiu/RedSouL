
#import "___FILEBASENAME___.h"

@implementation ___VARIABLE_categoryClass:identifier___ (___VARIABLE_categoryName:identifier___)

@end
